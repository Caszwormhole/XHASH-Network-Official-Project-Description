# XHASH Network V0.3 — Quorum & Consensus Prototype

This is a **single-process consensus simulation** for testing signed validator votes and quorum math. It is not a production distributed consensus protocol and does not yet communicate between PCs/Android devices.

## Design choices
- Validators are explicitly registered by public key. An unknown key cannot vote.
- Proposal ID is SHA-256 of canonical proposal content.
- Each vote is signed with Ed25519 and binds the proposal ID, validator ID, round, and decision.
- One vote per validator per proposal/round. Duplicate votes are rejected.
- Quorum threshold is `floor(2N/3) + 1` over the fixed validator set.
- An approval quorum marks the proposal `COMMITTED`; a rejection quorum marks it `REJECTED`; otherwise it remains `PENDING`.
- SQLite persists validators, proposals, and votes.

## Requirements
Python 3.10+ and `cryptography`.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS/Termux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Run a local simulation
```bash
python -m xhash_consensus demo --home ./xhash_v03_demo
```
The demo creates four *temporary demonstration validators* and three approval votes. Do not use demo keys as real node identities.

## Run tests
```bash
python -m unittest discover -s tests -v
```

## Important limitations
- This prototype does not implement peer-to-peer networking, authenticated membership updates, leader election, view changes, timeouts, durable distributed locks, anti-equivocation across separate databases, or Byzantine fault-tolerant consensus rounds.
- Quorum math alone does not make a network Byzantine fault tolerant. Production requires a formally specified protocol, stable validator-set epochs, network authentication, replay/round protection, and independent security review.
- SQLite here is local persistence, not a blockchain.
- A quorum confirms that enough registered validators voted for the same proposal; it does not prove the underlying external data is true.
