import argparse
import base64
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from .core import raw_public_key, validator_id_from_public_key, make_proposal, make_vote, tally_votes
from .store import ConsensusStore


def main():
    parser = argparse.ArgumentParser(prog="xhash-consensus")
    sub = parser.add_subparsers(dest="cmd", required=True)
    demo = sub.add_parser("demo", help="Run a local 4-validator quorum simulation")
    demo.add_argument("--home", default="./xhash_v03_demo")
    args = parser.parse_args()

    home = Path(args.home)
    home.mkdir(parents=True, exist_ok=True)
    keys_dir = home / "DEMO_KEYS_ONLY"
    keys_dir.mkdir(exist_ok=True)
    validators = {}
    private_keys = []
    for i in range(4):
        key_path = keys_dir / f"validator_{i+1}_private.pem"
        if key_path.exists():
            key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
        else:
            key = Ed25519PrivateKey.generate()
            pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
            key_path.write_bytes(pem)
            try: key_path.chmod(0o600)
            except OSError: pass
        pub = raw_public_key(key)
        vid = validator_id_from_public_key(pub)
        validators[vid] = pub
        private_keys.append(key)

    proposal = make_proposal({"feed": "demo", "record_hash": "sha256:example", "note": "not real market data"}, height=1)
    votes = [make_vote(key, proposal, "approve") for key in private_keys[:3]]
    with ConsensusStore(home / "consensus.sqlite") as store:
        for vid, pub in validators.items():
            store.register_validator(vid, base64.b64encode(pub).decode("ascii"), epoch=0)
        store.save_proposal(proposal)
        for vote in votes:
            if not store.save_vote(vote):
                print("Duplicate vote rejected by SQLite:", vote["validator_id"])
        result = tally_votes(proposal, votes, validators)
        store.set_status(proposal["proposal_id"], result["status"])
    print(json.dumps({"proposal": proposal, "result": result,
                      "note": "Local simulation only; not production consensus."}, indent=2))


if __name__ == "__main__":
    main()
