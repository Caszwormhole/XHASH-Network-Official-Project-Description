import base64
import hashlib
import json
from datetime import datetime, timezone

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


def canonical_json(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256_tagged(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def raw_public_key(private_key: Ed25519PrivateKey) -> bytes:
    return private_key.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    )


def validator_id_from_public_key(raw_key: bytes) -> str:
    return "validator:" + hashlib.sha256(raw_key).hexdigest()


def make_proposal(payload: dict, height: int, round_number: int = 0) -> dict:
    body = {
        "protocol": "XHASH-NETWORK",
        "version": "0.3.0",
        "height": int(height),
        "round": int(round_number),
        "payload": payload,
    }
    body["proposal_id"] = sha256_tagged(canonical_json(body))
    return body


def verify_proposal(proposal: dict) -> tuple[bool, str]:
    if not isinstance(proposal, dict):
        return False, "proposal must be an object"
    supplied_id = proposal.get("proposal_id")
    body = {k: v for k, v in proposal.items() if k != "proposal_id"}
    if not supplied_id or sha256_tagged(canonical_json(body)) != supplied_id:
        return False, "proposal ID/hash mismatch"
    if proposal.get("protocol") != "XHASH-NETWORK" or proposal.get("version") != "0.3.0":
        return False, "unsupported protocol/version"
    return True, "valid"


def make_vote(private_key, proposal: dict, decision: str = "approve") -> dict:
    if decision not in ("approve", "reject"):
        raise ValueError("decision must be 'approve' or 'reject'")
    pub = raw_public_key(private_key)
    validator_id = validator_id_from_public_key(pub)
    body = {
        "protocol": "XHASH-NETWORK",
        "version": "0.3.0",
        "proposal_id": proposal["proposal_id"],
        "height": proposal["height"],
        "round": proposal["round"],
        "validator_id": validator_id,
        "decision": decision,
        "timestamp": utc_now(),
    }
    body["signature"] = base64.b64encode(private_key.sign(canonical_json(body))).decode("ascii")
    body["public_key_base64"] = base64.b64encode(pub).decode("ascii")
    return body


def verify_vote(vote: dict, registered_validators: dict, proposal: dict) -> tuple[bool, str]:
    required = {"protocol", "version", "proposal_id", "height", "round",
                "validator_id", "decision", "timestamp", "signature", "public_key_base64"}
    if not isinstance(vote, dict) or not required.issubset(vote):
        return False, "missing fields or invalid vote object"
    if vote["protocol"] != "XHASH-NETWORK" or vote["version"] != "0.3.0":
        return False, "unsupported protocol/version"
    if vote["proposal_id"] != proposal["proposal_id"] or vote["height"] != proposal["height"] or vote["round"] != proposal["round"]:
        return False, "vote is for a different proposal/height/round"
    if vote["decision"] not in ("approve", "reject"):
        return False, "invalid decision"
    try:
        pub = base64.b64decode(vote["public_key_base64"], validate=True)
        if validator_id_from_public_key(pub) != vote["validator_id"]:
            return False, "validator ID does not match public key"
        # Membership is pinned by the registered set, not self-asserted by the vote.
        if registered_validators.get(vote["validator_id"]) != pub:
            return False, "validator is not registered"
        unsigned = {k: v for k, v in vote.items() if k not in ("signature", "public_key_base64")}
        sig = base64.b64decode(vote["signature"], validate=True)
        Ed25519PublicKey.from_public_bytes(pub).verify(sig, canonical_json(unsigned))
        return True, "valid"
    except (ValueError, TypeError, InvalidSignature):
        return False, "invalid public key or signature"


def quorum_threshold(validator_count: int) -> int:
    if validator_count < 1:
        raise ValueError("validator_count must be at least 1")
    return (2 * validator_count) // 3 + 1


def tally_votes(proposal: dict, votes: list, registered_validators: dict) -> dict:
    proposal_ok, proposal_reason = verify_proposal(proposal)
    n = len(registered_validators)
    if n == 0:
        raise ValueError("validator set cannot be empty")
    threshold = quorum_threshold(n)
    if not proposal_ok:
        return {
            "proposal_id": proposal.get("proposal_id") if isinstance(proposal, dict) else None,
            "validator_count": n,
            "quorum_threshold": threshold,
            "valid_approvals": 0,
            "valid_rejections": 0,
            "status": "PENDING",
            "invalid_votes": [{"reason": proposal_reason}],
        }
    seen = set()
    valid_approvals = 0
    valid_rejections = 0
    invalid = []
    for index, vote in enumerate(votes):
        ok, reason = verify_vote(vote, registered_validators, proposal)
        if not ok:
            invalid.append({"index": index, "reason": reason})
            continue
        vid = vote["validator_id"]
        if vid in seen:
            invalid.append({"index": index, "reason": "duplicate vote from validator"})
            continue
        seen.add(vid)
        if vote["decision"] == "approve":
            valid_approvals += 1
        else:
            valid_rejections += 1
    if valid_approvals >= threshold:
        status = "COMMITTED"
    elif valid_rejections >= threshold:
        status = "REJECTED"
    else:
        status = "PENDING"
    return {
        "proposal_id": proposal["proposal_id"],
        "validator_count": n,
        "quorum_threshold": threshold,
        "valid_approvals": valid_approvals,
        "valid_rejections": valid_rejections,
        "status": status,
        "invalid_votes": invalid,
    }
