import json
import sqlite3
from pathlib import Path

class ConsensusStore:
    def __init__(self, db_path):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS validators (
            validator_id TEXT PRIMARY KEY,
            public_key_base64 TEXT NOT NULL,
            epoch INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS proposals (
            proposal_id TEXT PRIMARY KEY,
            height INTEGER NOT NULL,
            round INTEGER NOT NULL,
            proposal_json TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING'
        );
        CREATE TABLE IF NOT EXISTS votes (
            proposal_id TEXT NOT NULL,
            height INTEGER NOT NULL,
            round INTEGER NOT NULL,
            validator_id TEXT NOT NULL,
            decision TEXT NOT NULL,
            vote_json TEXT NOT NULL,
            PRIMARY KEY (proposal_id, height, round, validator_id)
        );
        """)
        self.conn.commit()

    def register_validator(self, validator_id, public_key_b64, epoch=0):
        self.conn.execute("INSERT OR REPLACE INTO validators(validator_id, public_key_base64, epoch) VALUES(?,?,?)",
                          (validator_id, public_key_b64, epoch))
        self.conn.commit()

    def save_proposal(self, proposal):
        self.conn.execute("INSERT OR IGNORE INTO proposals(proposal_id,height,round,proposal_json,status) VALUES(?,?,?,?, 'PENDING')",
                          (proposal["proposal_id"], proposal["height"], proposal["round"], json.dumps(proposal, sort_keys=True)))
        self.conn.commit()

    def save_vote(self, vote):
        try:
            self.conn.execute("INSERT INTO votes(proposal_id,height,round,validator_id,decision,vote_json) VALUES(?,?,?,?,?,?)",
                              (vote["proposal_id"], vote["height"], vote["round"], vote["validator_id"], vote["decision"], json.dumps(vote, sort_keys=True)))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def set_status(self, proposal_id, status):
        self.conn.execute("UPDATE proposals SET status=? WHERE proposal_id=?", (status, proposal_id))
        self.conn.commit()

    def close(self):
        self.conn.close()

    def __enter__(self): return self
    def __exit__(self, exc_type, exc, tb): self.close()
