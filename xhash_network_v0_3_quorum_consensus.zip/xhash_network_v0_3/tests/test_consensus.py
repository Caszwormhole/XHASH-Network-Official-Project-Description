import tempfile
import unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from xhash_consensus.core import (
    raw_public_key, validator_id_from_public_key, make_proposal, make_vote,
    tally_votes, quorum_threshold
)

def setup_validators(count=4):
    keys = [Ed25519PrivateKey.generate() for _ in range(count)]
    registered = {validator_id_from_public_key(raw_public_key(k)): raw_public_key(k) for k in keys}
    return keys, registered

class ConsensusTests(unittest.TestCase):
    def test_thresholds(self):
        self.assertEqual(quorum_threshold(4), 3)
        self.assertEqual(quorum_threshold(7), 5)

    def test_three_of_four_commits(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        votes = [make_vote(k, p) for k in keys[:3]]
        self.assertEqual(tally_votes(p, votes, registered)["status"], "COMMITTED")

    def test_two_of_four_remains_pending(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        votes = [make_vote(k, p) for k in keys[:2]]
        self.assertEqual(tally_votes(p, votes, registered)["status"], "PENDING")

    def test_unknown_validator_rejected(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        unknown = Ed25519PrivateKey.generate()
        result = tally_votes(p, [make_vote(unknown, p)] + [make_vote(k, p) for k in keys[:2]], registered)
        self.assertEqual(result["status"], "PENDING")
        self.assertTrue(result["invalid_votes"])

    def test_tampered_vote_rejected(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        vote = make_vote(keys[0], p)
        vote["decision"] = "reject"
        result = tally_votes(p, [vote] + [make_vote(k, p) for k in keys[1:3]], registered)
        self.assertEqual(result["status"], "PENDING")
        self.assertTrue(result["invalid_votes"])

    def test_tampered_proposal_payload_fails(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        votes = [make_vote(k, p) for k in keys[:3]]
        p["payload"]["hash"] = "tampered"
        result = tally_votes(p, votes, registered)
        self.assertEqual(result["status"], "PENDING")
        self.assertEqual(result["valid_approvals"], 0)
        self.assertTrue(result["invalid_votes"])

    def test_duplicate_vote_counts_once(self):
        keys, registered = setup_validators(4)
        p = make_proposal({"hash": "x"}, 1)
        v = make_vote(keys[0], p)
        votes = [v, v, make_vote(keys[1], p)]
        result = tally_votes(p, votes, registered)
        self.assertEqual(result["valid_approvals"], 2)
        self.assertEqual(result["status"], "PENDING")

if __name__ == "__main__":
    unittest.main()
